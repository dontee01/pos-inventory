
<?php $__env->startSection('title', '::.Item'); ?>
<?php $__env->startSection('content'); ?>

    <section class="content bg-default">
            <div class="container-fluid">

    <!-- Display Validation Errors -->
        <?php echo $__env->make('common.errors', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if(Session::has('flash_message')): ?>
        <div align="center" class="alert alert-danger alert-dismissable mw800 center-block">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true" color="blue">x</button>
            <strong><?php echo e(Session::get('flash_message')); ?></strong>

            <br><br>

        </div>
        <?php endif; ?>

        <?php if(Session::has('flash_message_success')): ?>
        <div align="center" class="alert alert-success alert-dismissable mw800 center-block">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true" color="blue">x</button>
            <strong><?php echo e(Session::get('flash_message_success')); ?></strong>

            <br><br>

        </div>
        <?php endif; ?>

        
        <form method="post" action="<?php echo e(url('item/add')); ?>">
         <?php echo e(csrf_field()); ?>

        <div class="row modal-row">

        <div class="panel-body">
            <div class="">
                <div class=form-group>
                    <select class="form-control" name="category" id="add-product-category" title="Choose a category">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="panel-body">
            <div class="">
                <div class=form-group>
                 <input class="form-control" type="text" name="item" id="add-product-item" placeholder="Item" title="Item Name" />
                </div>
            </div>
        </div>

        <div class="panel-body">
            <div class="">
                <div >
                <label><input class="form-control" type="checkbox" name="is_rgb" id="add-product-is-rgb" title="Rgb" />Bottle</label>
                </div>
                <span class="help-block medium">Tick this box if item is RGB</span>
            </div>
        </div>
<div id="rgb">
        <div class="panel-body">
            <div class="">
                <div class=form-group>
                 <input class="form-control" type="text" name="qty_content" id="add-product-content" placeholder="Content" title="Content (Crates)" />
                </div>
            </div>
        </div>

        <div class="panel-body">
            <div class="">
                <div class=form-group>
                 <input class="form-control" type="text" name="qty_bottle" id="add-product-bottle" placeholder="Empty bottles" title="Empty Bottles (Crates)" />
                </div>
            </div>
        </div>
</div>

        <div class="panel-body" id="nrgb">
            <div class="">
                <div class=form-group>
                 <input class="form-control" type="text" name="qty" id="add-product-qty" placeholder="Quantity" title="Quantity" />
                </div>
            </div>
        </div>

        <div class="panel-body">
            <div class="">
                <div class=form-group>
                 <input class="form-control" type="text" name="price" id="add-product-price" placeholder="Price" title="Price" />
                </div>
            </div>
        </div>


        </div>

        <div class="modal-footer">
            <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
            <button type="submit" class="btn btn-danger btn-recharge" id="add-product-save" >Save</button>
            <button type="reset" class="btn btn-modal-save pull-left" >Cancel</button>
        </div>

        </form>
        </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Herd\ireport\resources\views/item-add.blade.php ENDPATH**/ ?>