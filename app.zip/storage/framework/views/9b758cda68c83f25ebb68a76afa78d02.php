
<?php $__env->startSection('title', '::.Order'); ?>
<?php $__env->startSection('content'); ?>


<section class="content bg-default">
    <div class="container-fluid">

    <!-- Display Validation Errors -->
        <?php echo $__env->make('common.errors', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if(Session::has('flash_message')): ?>
        <div align="center" class="alert alert-danger alert-dismissable mw800 center-block">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true" color="blue">x</button>
            <strong><?php echo e(Session::get('flash_message')); ?></strong>

            <br><br>

        </div>
        <?php endif; ?>

        <?php if(Session::has('flash_message_success')): ?>
        <div align="center" class="alert alert-success alert-dismissable mw800 center-block">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true" color="blue">x</button>
            <strong><?php echo e(Session::get('flash_message_success')); ?></strong>

            <br><br>

        </div>
        <?php endif; ?>



<div class="row">

    <div class="col-md-9">

        <div class="row">

        <div class="col-md-3">
            <div class="panel">
                <!-- <div class="panel-body"> -->
                    <h1 class="m-t-md m-b-xs" style="margin-top: 30px">
                        <!-- <i class="pe pe-7s-global text-warning"> </i> -->
                        Products
                    </h1>
                    <div class="small">
                        <select class="input-sm" onchange="location = this.value;">
                            <option value="">Select an item</option>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(url('order/'.$item['id'])); ?>""><?php echo e($item['i_name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="help-block small">Choose a product</span>
                    </div>
                    <div class="m-t-sm">
                      
                    </div>
                <!-- </div> -->
            </div>
        </div>

        <div class="col-md-9" style="display:none;">
            <!-- <h1>Inventory App</h1> -->

            <div class=" form-inline">
                <div class="form-group form-group-sm">
                <select class="input-sm " title="Select a customer" name="customer">
                    <option value="">Select Customer</option>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($customer->c_name); ?>"><?php echo e($customer->c_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="help-block small">Choose a customer</span>
                </div>

                <div class="form-group form-group-sm">
                    <input class="input-sm" type="text" name="quantity-bottle" id="add-quantity-bottle" title="Quantity" readonly="readonly" />
                    <span class="help-block small">Empty Bottles Left</span>
                </div>

                <div class="form-group form-group-sm">
                    <input class="input-sm" type="text" name="quantity-content" id="add-quantity-content" title="Quantity" readonly="readonly" />
                    <span class="help-block small">Bottles with Content Left</span>
                </div>
            </div>

            <div class="form-group form-group-sm">
                <input class="input-sm" type="text" name="quantity" id="add-quantity" placeholder="Quantity" title="Quantity" />
                <span class="help-block small">Quantity</span>
            </div>

            <!-- <div class="form-group form-group-sm">
                <button class="btn btn-default btn-rounded btn-block" id="add-to-cart" type="submit">Add To Cart</button>
            </div> -->
        </div>
        
        
            
        </div>
        <!-- end row -->
    </div>
    <!-- end main col-8 -->


    <div class="col-md-3">
        <div class="panel">
            <div class="panel-body">
                <h1 class="m-t-md m-b-xs" style="margin-top: 30px">
                    <!-- <i class="pe pe-7s-global text-warning"> </i> -->
                    Ads
                </h1>
                <div class="small">
                <!-- Ads -->
                </div>
                <div class="m-t-sm">
                  
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end main row -->


    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Herd\ireport\resources\views/order.blade.php ENDPATH**/ ?>