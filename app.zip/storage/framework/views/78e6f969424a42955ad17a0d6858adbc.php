
<?php $__env->startSection('title', '::.Purchase'); ?>
<?php $__env->startSection('content'); ?>


<section class="content bg-default">
    <div class="container-fluid">

    <!-- Display Validation Errors -->
        <?php echo $__env->make('common.errors', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if(Session::has('flash_message')): ?>
        <div align="center" class="alert alert-danger alert-dismissable mw800 center-block">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true" color="blue">x</button>
            <strong><?php echo e(Session::get('flash_message')); ?></strong>

            <br><br>

        </div>
        <?php endif; ?>

        <?php if(Session::has('flash_message_success')): ?>
        <div align="center" class="alert alert-success alert-dismissable mw800 center-block">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true" color="blue">x</button>
            <strong><?php echo e(Session::get('flash_message_success')); ?></strong>

            <br><br>

        </div>
        <?php endif; ?>



<div class="row">

    <div class="col-md-10">

        <div class="row">

        <div class="col-md-4">
            <div class="panel">
                <!-- <div class="panel-body"> -->
                    <h1 class="m-t-md m-b-xs" style="margin-top: 30px">
                        <!-- <i class="pe pe-7s-global text-warning"> </i> -->
                        Purchase
                    </h1><br />
                    <div class="small">
                        <select class="input-sm" onchange="location = this.value;">
                            <option value="">Select an item</option>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(url('purchase/show/'.$item['id'])); ?>"><?php echo e($item['i_name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="help-block small">Choose a product</span>
                    </div>
                    <br />
                    <?php if(!empty($category)): ?>
                    <span class="text-warning">
                        <?php echo e($category.'+'.$details->i_name); ?>

                    </span>
                    <?php endif; ?>
                    <div class="m-t-sm">
                      
                    </div>
                <!-- </div> -->
            </div>
        </div>

        <div class="col-md-8">
            <!-- <h1>Purchase</h1> -->
            <form action="<?php echo e(url('purchase/cart/add')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <?php if(!empty($details)): ?>
                <div class=" form-inline">
                    <div class="form-group form-group-sm">
                    <select class="input-sm " title="Select a supplier" name="supplier" required="required">
                        <option value="">Select Supplier</option>
                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($supplier->s_name); ?>"><?php echo e($supplier->s_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="help-block small">Choose a supplier</span>
                    </div>

                    <!-- <div class="form-group form-group-sm">
                    <select class="input-sm " title="Select a driver" name="driver" required="required">
                        <option value="">Select Driver</option>
                            <option value="Individual">Individual</option>
                    </select>
                    <span class="help-block small">&nbsp;</span>
                    </div> -->
                    
                    <input class="input-sm" type="hidden" name="is_rgb" id="add-quantity-is-rgb" readonly="readonly" value="<?php echo e($details->is_rgb); ?>" />
                    <input class="input-sm" type="hidden" name="item_id" id="add-quantity-is-item-id" readonly="readonly" value="<?php echo e($details->id); ?>" />
                    <input class="input-sm" type="hidden" name="item_name" id="add-quantity-is-item-name" readonly="readonly" value="<?php echo e($category.'+'.$details->i_name); ?>" />
                    <input class="input-sm" type="hidden" name="transaction_ref" id="add-quantity-is-rgb" readonly="readonly" value="<?php echo e(Session::get('transaction_ref')); ?>" />

                    <?php if($details->is_rgb): ?>
                    <div class="form-group form-group-sm">
                        <input class="input-sm" type="text" name="quantity_bottle" id="add-quantity-bottle" title="Quantity" readonly="readonly" value="<?php echo e($details->qty_bottle); ?>" />
                        <span class="help-block small">Empty Bottles Left</span>
                    </div>

                    <div class="form-group form-group-sm">
                        <input class="input-sm" type="text" name="quantity_content" id="add-quantity-content" title="Quantity" readonly="readonly" value="<?php echo e($details->qty_content); ?>" />
                        <span class="help-block small">Bottles with Content Left</span>
                    </div>

                    <div class="form-group form-group-sm">
                    <select class="input-sm " title="Select an exchange mode" name="purchase_type" required="required">
                        <option value="">Select an exchange mode</option>
                            <option value="1">Exchange Bottle</option>
                            <option value="0">No Exchange</option>
                    </select>
                    <span class="help-block small">&nbsp;</span>
                    </div>
                    <?php endif; ?>

                    <?php if($details->is_rgb == 0): ?>
                    <div class="form-group form-group-sm">
                        <input class="input-sm" type="text" name="qty" id="add-quantity-qty" title="Quantity Left" readonly="readonly" value="<?php echo e($details->qty); ?>" />
                        <span class="help-block small">Quantity Left</span>
                    </div>
                    <?php endif; ?>

                </div>


                <div class="form-group form-group-sm">
                    <input class="input-sm" type="text" v-model="quantity" name="quantity" id="add-quantity" title="Quantity" required="required" />
                    <span class="help-block small">Quantity</span>
                </div>

                <div class=" form-inline">

                    <div class="form-group form-group-sm">
                        <input class="input-sm" type="text" v-model="price" name="price" id="add-quantity-price" title="Unit Price" value="<?php echo e($details->price_unit); ?>" required="required" />
                        <span class="help-block small">Unit Price</span>
                    </div>

                    <div class="form-group form-group-sm">
                        <input class="input-sm" type="text" name="sub_total" id="add-quantity-sub" title="Sub Total" readonly="readonly" value="{{quantity * price}}" required="required" />
                        <span class="help-block small">Sub Total</span>
                    </div>
                </div>

                <div class=" form-inline">

                    <div class="form-group form-group-sm">
                        <input class="input-sm" type="text" name="amount" id="purchase-amount" title="Amount Paid" required="required" />
                        <span class="help-block small">Amount Paid</span>
                    </div>

                    <div class="form-group form-group-sm">
                        <input type="checkbox" id="is-discount" name="is_discount" value="1" />
                    <label for="is_discount"><span class="help-inline small">Rebate</span></label>
                    </div>

                    <div id="purchase-rebate" class="form-group form-group-sm">
                        <input class="input-sm" type="text" name="quantity_rebate" id="rebate-quantity" title="Rebate Quantity"/>
                        <span class="help-block small">Rebate Quantity</span>
                    </div>

                </div>

                <!-- <div class="form-group form-group-sm">
                    <textarea name="comment" rows="3" cols="5" class="form-control"></textarea>
                    <span class="help-block small">Comment</span>
                </div> -->

                <div class="form-group form-group-sm">
                    <button class="btn btn-default btn-rounded btn-block" id="purchase-add" type="submit">Add To Cart</button>
                </div>
            <?php endif; ?>

            </form>

        </div>
        
        
            
        </div>
        <!-- end row -->


    </div>
    <!-- end main col-8 -->


    <div class="col-md-2">
        <div class="panel">
            <div class="panel-body">
                <h1 class="m-t-md m-b-xs" style="margin-top: 30px">
                    <i class="pe pe-7s-cart text-warning"> </i>
                    Cart
                </h1>
                <div class="small">
                <!-- Ads -->
                </div>
                <div class="m-t-sm">
                <?php if(count($cart_items) == 0): ?>
                <div class="small">
                Cart is empty
                </div>
                <?php else: ?>
                <div class="small">
                    <?php if(count($cart_items) > 1): ?>
                    <?php echo e(count($cart_items)); ?> Items ready to be processed

                    <?php elseif(count($cart_items) == 1): ?>
                    <?php echo e(count($cart_items)); ?> Item ready to be processed

                    <?php endif; ?>
                </div><br />

                <a class="btn btn-default btn-rounded" href="<?php echo e(url('purchase/cart')); ?>">View Cart</a>
                <?php endif; ?>
                </div>

                <div class="small">
                    <p>
                        Select any of the product you want to purchase from the drop down
                    </p>
                    <p>
                        <b>Select No exchange if you are buying both bottle and liquid</b>
                    </p>
                    <p>
                        Click add to cart when you are done, then <b>View Cart</b> to finalize purchase
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end main row -->


    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Herd\ireport\resources\views/purchase.blade.php ENDPATH**/ ?>