
<?php $__env->startSection('title', '::.Driver'); ?>
<?php $__env->startSection('content'); ?>

    <section class="content bg-default">
            <div class="container-fluid">

        <!-- Display Validation Errors -->
        <?php echo $__env->make('common.errors', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if(Session::has('flash_message')): ?>
        <div align="center" class="alert alert-danger alert-dismissable mw800 center-block">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true" color="blue">x</button>
            <strong><?php echo e(Session::get('flash_message')); ?></strong>

            <br><br>

        </div>
        <?php endif; ?>

        <?php if(Session::has('flash_message_success')): ?>
        <div align="center" class="alert alert-success alert-dismissable mw800 center-block">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true" color="blue">x</button>
            <strong><?php echo e(Session::get('flash_message_success')); ?></strong>

            <br><br>

        </div>
        <?php endif; ?>
        
        <form method="post" action="<?php echo e(url('driver/add')); ?>">
         <?php echo e(csrf_field()); ?>

        <div class="row modal-row">


        <div class="panel-body">
            <div class="">
                <div class=form-group>
                 <input class="form-control" type="text" name="d_name" id="add-driver-name" placeholder="Driver Name" title="Driver Name" />
                </div>
            </div>
            <span class="help-block small">Driver Name</span>
        </div>

        <div class="panel-body">
            <div class="">
                <div class=form-group>
                 <input class="form-control" type="text" name="phone" id="add-driver-phone" placeholder="Phone Number" title="Driver Phone Number" />
                </div>
            </div>
            <span class="help-block small">Driver Phone Number</span>
        </div>
        <div class="panel-body">
            <div class="">
                <div class=form-group>
                <textarea name="address" id="add-driver-address" placeholder="Address" title="Driver Address"></textarea>
                </div>
            </div>
            <span class="help-block small">Driver Address</span>
        </div>


        </div>

        <div class="modal-footer">
            <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
            <button type="submit" class="btn btn-danger btn-recharge" id="add-driver-save" >Save</button>
            <button type="reset" class="btn btn-modal-save pull-left" >Cancel</button>
        </div>

        </form>
        </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Herd\ireport\resources\views/driver-add.blade.php ENDPATH**/ ?>