
<?php $__env->startSection('title', '::.Process Pending Order'); ?>
<?php $__env->startSection('content'); ?>


<section class="content bg-default">
    <div class="container-fluid">

    <!-- Display Validation Errors -->
        <?php echo $__env->make('common.errors', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if(Session::has('flash_message')): ?>
        <div align="center" class="alert alert-danger alert-dismissable mw800 center-block">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true" color="blue">x</button>
            <strong><?php echo e(Session::get('flash_message')); ?></strong>

            <br><br>

        </div>
        <?php endif; ?>

        <?php if(Session::has('flash_message_success')): ?>
        <div align="center" class="alert alert-success alert-dismissable mw800 center-block">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true" color="blue">x</button>
            <strong><?php echo e(Session::get('flash_message_success')); ?></strong>

            <br><br>

        </div>
        <?php endif; ?>



<div class="row">

    <div class="col-md-9">

        <div class="row">

        <div class="col-md-12">
            <h1>Pending Orders</h1>

            <div class="m-t-sm">
                <?php if(count($order) != 0): ?>
                <!-- <div class="small">
                Cart is empty
                </div> -->
                <table class="table table-hover table-striped" id="table-custom">
                    <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Item</th>
                        <th>Quantity</th>
                        <th>Sub Total</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>1</td>
                        <td><?php echo e($order['i_name']); ?></td>
                        <td><?php echo e($order['qty']); ?></td>
                        <td><?php echo e($order['price_total']); ?>

                        <input type="hidden" id="id-add-item" value="<?php echo e($order['id']); ?>" />
                        </td>
                    </tr>

                    </tbody>
                </table>

                <div class="form-group form-group-sm">
                    <!-- <button class="btn btn-danger btn-rounded btn-block" id="add-to-cart" type="submit">Checkout</button> -->
                </div>
                <?php endif; ?>

            </div>

        </div>
        
        
            
        </div>
        <!-- end row -->
        

        <div class="row">

            <div class="col-md-12">
                <div class="panel">
                    <div class="panel-body">
                        <h1 class="m-t-md m-b-xs" style="margin-top: 30px">
                            <!-- <i class="pe pe-7s-global text-warning"> </i> -->
                            <!-- Returned Items -->
                        </h1>
                        <div class="small">
                            
                        </div>
                        <div class="m-t-sm">
                          
                        <form action="<?php echo e(url('pending/checkout/'.$order['id'])); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                            <div class=" form-inline">


                                <?php if($order['is_rgb']): ?>
                                <div class="form-group form-group-sm">
                                    <input class="input-sm" type="text" name="quantity_bottle" id="check-quantity-bottle" title="Quantity" required="required" value="0" />
                                    <span class="help-block small">Empty Bottles Returned</span>
                                </div>

                                <div class="form-group form-group-sm">
                                    <input class="input-sm" type="text" name="quantity_content" id="check-quantity-content" title="Quantity" required="required" value="0" />
                                    <span class="help-block small">Bottles with Content Returned</span>
                                </div>
                                <?php endif; ?>

                                <?php if($order['is_rgb'] == 0): ?>
                                <div class="form-group form-group-sm">
                                    <input class="input-sm" type="text" name="qty" id="check-quantity-qty" title="Quantity Returned" required="required" value="0" />
                                    <span class="help-block small">Quantity Returned</span>
                                </div>
                                <?php endif; ?>
                                <input class="input-sm" type="hidden" name="is_rgb" id="check-quantity-is-rgb" readonly="readonly" value="<?php echo e($order['is_rgb']); ?>" />

                            </div>

                            <div class="form-group form-group-sm">
                                <button class="btn btn-danger btn-rounded btn-block" id="add-to-cart" type="submit">Checkout</button>
                            </div>

                        </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- end row -->



    </div>
    <!-- end main col-8 -->


    <div class="col-md-3">
        <!-- <div class="panel">
            <div class="panel-body">

            </div>
        </div> -->
    </div>
</div>
<!-- end main row -->


    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Herd\ireport\resources\views/pending-process.blade.php ENDPATH**/ ?>