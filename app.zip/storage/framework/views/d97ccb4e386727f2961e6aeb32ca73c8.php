
<?php $__env->startSection('title', '::.Home'); ?>
<?php $__env->startSection('content'); ?>

    <section class="content bg-default">
            <div class="container-fluid">

                <div class="row">
                <div class="col-md-8 center" align="center">

<p><h4>Inventory Management System</h4></p>
<div>
	Use the links on the side bar to navigate through this app
</div>
                </div>
                </div>
            </div>
    </section>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Herd\ireport\resources\views/home.blade.php ENDPATH**/ ?>