@extends('layouts.layout')
@section('title', '::.Home')
@section('content')

    <section class="content bg-default">
            <div class="container-fluid">

                <div class="row">
                <div class="col-md-8 center" align="center">

<p><h4>Inventory Management System</h4></p>
<div>
	Use the links on the side bar to navigate through this app
</div>
                </div>
                </div>
            </div>
    </section>
    

@endsection